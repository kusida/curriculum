package study;

public class Calculator {

    protected int plus(int a) {
        return a + 1;
    }

    protected int plus(int a, int b) {
        return a + b;
    }

    protected int plus(int a, int b, int c) {
        return a + b + c;
    }

}
